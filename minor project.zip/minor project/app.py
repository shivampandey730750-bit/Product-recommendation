"""
Smart Product Recommendation System - Streamlit Web Application.
B.Tech 3rd-Year AIML Capstone Project.
Features: Content-Based, Collaborative Filtering, Hybrid Engine, Wishlist,
Analytics Dashboard, Offline Evaluation, and Viva Voce Guide.
"""
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional

import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Ensure UTF-8 stdout if needed
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.config import (
    APP_TITLE,
    APP_SUBTITLE,
    CURRENCY_SYMBOL,
    DEFAULT_HYBRID_ALPHA,
    DEFAULT_TOP_K,
    FALLBACK_IMAGE_URL,
)
from src.data_loader import load_products, load_ratings, get_dataset_summary
from src.content_based import ContentBasedRecommender
from src.collaborative import CollaborativeRecommender
from src.hybrid import HybridRecommender
from src.evaluation import evaluate_recommenders
from src.utils import inject_custom_css, format_currency, render_stars


# ==========================================
# PAGE CONFIGURATION
# ==========================================
st.set_page_config(
    page_title="Smart Product Recommendation System",
    page_icon="🛍️",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Inject modern CSS styling
inject_custom_css()


# ==========================================
# CACHED DATA & MODEL LOADING
# ==========================================
@st.cache_data(show_spinner=False)
def get_data():
    """Load and preprocess products and user ratings."""
    products_df = load_products()
    ratings_df = load_ratings()
    return products_df, ratings_df


@st.cache_resource(show_spinner=False)
def init_models(products_df: pd.DataFrame, ratings_df: pd.DataFrame):
    """Instantiate ML recommendation engines."""
    content_engine = ContentBasedRecommender(products_df)
    collab_engine = CollaborativeRecommender(ratings_df, products_df)
    hybrid_engine = HybridRecommender(
        content_engine, collab_engine, default_alpha=DEFAULT_HYBRID_ALPHA
    )
    return content_engine, collab_engine, hybrid_engine


products_df, ratings_df = get_data()
content_engine, collab_engine, hybrid_engine = init_models(products_df, ratings_df)
dataset_summary = get_dataset_summary(products_df, ratings_df)


# ==========================================
# SESSION STATE INITIALIZATION
# ==========================================
if "wishlist" not in st.session_state:
    st.session_state.wishlist = ["P101", "P103"]  # Seed with 2 demo items

if "selected_product_id" not in st.session_state:
    st.session_state.selected_product_id = "P101"

if "current_user_id" not in st.session_state:
    st.session_state.current_user_id = "U101"

if "active_nav" not in st.session_state:
    st.session_state.active_nav = "🛍️ Storefront & Catalog"


def toggle_wishlist(pid: str):
    """Add or remove product from session wishlist."""
    if pid in st.session_state.wishlist:
        st.session_state.wishlist.remove(pid)
    else:
        st.session_state.wishlist.append(pid)


def view_product_details(pid: str):
    """Navigate to product details view."""
    st.session_state.selected_product_id = pid
    st.session_state.active_nav = "🔍 Product Detail & Similar"


# ==========================================
# SIDEBAR NAVIGATION & CONTROLS
# ==========================================
with st.sidebar:
    st.markdown("### 🛍️ SmartRec System")

    nav_options = [
        "🛍️ Storefront & Catalog",
        "🔍 Product Detail & Similar",
        "👤 Personalized 'For You'",
        "💖 My Wishlist",
        "📊 ML Analytics & Dashboard",
        "🧪 Offline Model Evaluation",
        "🎓 B.Tech Viva Voce & Guide",
    ]

    selected_nav = st.radio(
        "Navigation",
        options=nav_options,
        index=nav_options.index(st.session_state.active_nav)
        if st.session_state.active_nav in nav_options
        else 0,
    )
    st.session_state.active_nav = selected_nav

    st.markdown("---")
    st.markdown("#### 👤 Active User Simulation")
    known_users = collab_engine.get_known_users()
    user_options = ["Guest (Cold Start)"] + known_users

    current_idx = 0
    if st.session_state.current_user_id in known_users:
        current_idx = known_users.index(st.session_state.current_user_id) + 1

    selected_user = st.selectbox(
        "Simulate Logged-in User:",
        options=user_options,
        index=current_idx,
        help="Select a user persona to test personalized collaborative & hybrid recommendations.",
    )

    if selected_user == "Guest (Cold Start)":
        st.session_state.current_user_id = "GUEST_COLD_START"
        st.info("Currently browsing as **Guest / New User** (tests cold-start fallback).")
    else:
        st.session_state.current_user_id = selected_user
        # Show quick profile summary
        user_history = collab_engine.get_user_history(selected_user)
        st.success(f"**{selected_user}** ({len(user_history)} rated items)")

    st.markdown("---")
    wishlist_count = len(st.session_state.wishlist)
    st.markdown(
        f"**💖 Wishlist Items:** `{wishlist_count}`",
        help="Click 'My Wishlist' to see saved products and personalized recommendations based on your wishlist.",
    )

    st.markdown("---")
    st.caption("Built with Python • Scikit-Learn • Streamlit")


# ==========================================
# PAGE 1: STOREFRONT & CATALOG
# ==========================================
if st.session_state.active_nav == "🛍️ Storefront & Catalog":
    st.markdown(
        f"""
        <div class="hero-banner">
            <div class="hero-title">{APP_TITLE}</div>
            <div class="hero-subtitle">{APP_SUBTITLE} • Discover tailored products using TF-IDF Content Similarity & Collaborative Filtering</div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Top Search and Filter Bar
    col1, col2, col3, col4 = st.columns([3, 2, 2, 1.5])
    with col1:
        search_query = st.text_input(
            "🔍 Search Products",
            placeholder="Search by name, brand, or feature (e.g. noise cancelling, laptop, coffee)...",
        )
    with col2:
        all_categories = ["All Categories"] + sorted(products_df["category"].unique().tolist())
        selected_category = st.selectbox("Category", options=all_categories)
    with col3:
        max_price = float(products_df["price"].max())
        price_limit = st.slider(
            "Max Price",
            min_value=10.0,
            max_value=max_price,
            value=max_price,
            step=10.0,
            format=f"{CURRENCY_SYMBOL}%.0f",
        )
    with col4:
        sort_by = st.selectbox(
            "Sort By",
            options=["Rating: High to Low", "Price: Low to High", "Price: High to Low", "Popularity"],
        )

    # Filter logic
    filtered_df = products_df.copy()

    if search_query.strip():
        q = search_query.strip().lower()
        filtered_df = filtered_df[
            filtered_df["name"].str.lower().str.contains(q)
            | filtered_df["description"].str.lower().str.contains(q)
            | filtered_df["tags"].str.lower().str.contains(q)
            | filtered_df["brand"].str.lower().str.contains(q)
        ]

    if selected_category != "All Categories":
        filtered_df = filtered_df[filtered_df["category"] == selected_category]

    filtered_df = filtered_df[filtered_df["price"] <= price_limit]

    # Sorting
    if sort_by == "Rating: High to Low":
        filtered_df = filtered_df.sort_values(by=["rating", "rating_count"], ascending=[False, False])
    elif sort_by == "Price: Low to High":
        filtered_df = filtered_df.sort_values(by="price", ascending=True)
    elif sort_by == "Price: High to Low":
        filtered_df = filtered_df.sort_values(by="price", ascending=False)
    elif sort_by == "Popularity":
        filtered_df = filtered_df.sort_values(by="rating_count", ascending=False)

    st.markdown(
        f"**Showing {len(filtered_df)} of {len(products_df)} Products**"
    )

    if filtered_df.empty:
        st.warning("No products match your search/filter criteria. Try adjusting the search keywords or filters.")
    else:
        # Display products in a 3-column responsive grid
        cols = st.columns(3)
        for i, (_, row) in enumerate(filtered_df.iterrows()):
            pid = row["product_id"]
            col = cols[i % 3]

            with col:
                is_wishlisted = pid in st.session_state.wishlist
                heart_icon = "❤️" if is_wishlisted else "🤍"

                # Render Card Container
                with st.container():
                    st.markdown(
                        f"""
                        <div class="product-card">
                            <span class="badge-category">{row['category']}</span>
                            <div class="badge-brand">{row.get('brand', 'Premium Brand')}</div>
                            <div class="product-title">{row['name']}</div>
                            <div class="product-desc">{row['description']}</div>
                            <div style="display:flex; justify-content:space-between; align-items:center; margin-top:auto; padding-top:0.5rem;">
                                <span class="product-price">{format_currency(row['price'])}</span>
                                <span class="product-rating">★ {row['rating']:.1f} ({row['rating_count']})</span>
                            </div>
                        </div>
                        """,
                        unsafe_allow_html=True,
                    )

                    # Card Interactive Buttons
                    btn_col1, btn_col2 = st.columns([1.2, 1])
                    with btn_col1:
                        if st.button(
                            "🔍 View Details & Similar",
                            key=f"view_{pid}",
                            use_container_width=True,
                        ):
                            view_product_details(pid)
                            st.rerun()

                    with btn_col2:
                        btn_label = "Remove" if is_wishlisted else "Wishlist"
                        if st.button(
                            f"{heart_icon} {btn_label}",
                            key=f"wish_{pid}",
                            use_container_width=True,
                        ):
                            toggle_wishlist(pid)
                            st.rerun()

                    st.markdown("<div style='margin-bottom:1.2rem;'></div>", unsafe_allow_html=True)


# ==========================================
# PAGE 2: PRODUCT DETAIL & SIMILAR
# ==========================================
elif st.session_state.active_nav == "🔍 Product Detail & Similar":
    st.markdown("## 🔍 Product Detail & Intelligent Similar Recommendations")

    # Product Selector
    col_sel, col_algo = st.columns([3, 1.5])
    with col_sel:
        prod_names = {row["product_id"]: f"{row['name']} ({row['category']} - {format_currency(row['price'])})" for _, row in products_df.iterrows()}
        selected_pid = st.selectbox(
            "Select Product to Inspect:",
            options=list(prod_names.keys()),
            format_func=lambda x: prod_names[x],
            index=list(prod_names.keys()).index(st.session_state.selected_product_id)
            if st.session_state.selected_product_id in prod_names
            else 0,
        )
        st.session_state.selected_product_id = selected_pid

    with col_algo:
        rec_mode = st.radio(
            "Recommendation Strategy:",
            options=["Content-Based (TF-IDF + Cosine)", "Hybrid (Content + User CF)"],
            help="Compare Content-Based NLP similarity vs Hybrid recommendation.",
        )

    target_prod = products_df[products_df["product_id"] == selected_pid].iloc[0]

    # Target Product Presentation Box
    st.markdown(
        f"""
        <div class="detail-container">
            <div style="display:flex; justify-content:space-between; align-items:flex-start; flex-wrap:wrap; gap:1rem;">
                <div style="flex:2; min-width:300px;">
                    <span class="badge-category">{target_prod['category']} • {target_prod.get('subcategory', 'General')}</span>
                    <h2 style="margin:0.3rem 0; color:#0f172a;">{target_prod['name']}</h2>
                    <p style="color:#64748b; font-weight:600; margin-bottom:0.8rem;">Brand: {target_prod.get('brand', 'Generic')}</p>
                    <p style="color:#334155; line-height:1.6; font-size:1rem;">{target_prod['description']}</p>
                    <div style="margin-top:1rem;">
                        <span class="product-price" style="font-size:1.8rem; margin-right:1.5rem;">{format_currency(target_prod['price'])}</span>
                        <span class="product-rating" style="font-size:1.1rem;">★ {target_prod['rating']:.1f} / 5.0 ({target_prod['rating_count']} reviews)</span>
                    </div>
                </div>
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    # Action bar for selected product
    act_col1, act_col2 = st.columns([1.5, 4])
    with act_col1:
        is_in_wish = selected_pid in st.session_state.wishlist
        wish_txt = "❤️ In Wishlist (Click to Remove)" if is_in_wish else "🤍 Add to Wishlist"
        if st.button(wish_txt, key="target_wish_toggle", use_container_width=True):
            toggle_wishlist(selected_pid)
            st.rerun()

    st.markdown("---")
    st.markdown("### 🎯 Recommended Similar Products")
    st.caption("Excluding the inspected product itself. Explanations show the exact mathematical rationale.")

    # Generate recommendations
    if "Content-Based" in rec_mode:
        similar_items = content_engine.get_similar_products(selected_pid, top_k=6)
    else:
        # Hybrid
        active_u = (
            None
            if st.session_state.current_user_id == "GUEST_COLD_START"
            else st.session_state.current_user_id
        )
        similar_items = hybrid_engine.recommend(
            user_id=active_u,
            anchor_product_id=selected_pid,
            top_k=6,
            alpha=0.6,
        )

    if not similar_items:
        st.info("No similar products found.")
    else:
        rec_cols = st.columns(3)
        for idx, rec in enumerate(similar_items):
            with rec_cols[idx % 3]:
                rec_pid = rec["product_id"]
                match_label = rec.get("match_percentage", f"{rec.get('similarity_score', 0)*100:.0f}%")

                st.markdown(
                    f"""
                    <div class="product-card">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span class="badge-category">{rec['category']}</span>
                            <span class="badge-match">{match_label}</span>
                        </div>
                        <div class="badge-brand">{rec.get('brand', '')}</div>
                        <div class="product-title">{rec['name']}</div>
                        <div class="explanation-box">
                            <strong>Why recommended:</strong><br>{rec['explanation']}
                        </div>
                        <div class="product-desc">{rec['description']}</div>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:auto; padding-top:0.5rem;">
                            <span class="product-price">{format_currency(rec['price'])}</span>
                            <span class="product-rating">★ {rec['rating']:.1f}</span>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )

                sub_b1, sub_b2 = st.columns([1.2, 1])
                with sub_b1:
                    if st.button("Inspect Item", key=f"rec_inspect_{rec_pid}_{idx}", use_container_width=True):
                        view_product_details(rec_pid)
                        st.rerun()
                with sub_b2:
                    is_rec_wished = rec_pid in st.session_state.wishlist
                    h_icon = "❤️" if is_rec_wished else "🤍"
                    if st.button(f"{h_icon}", key=f"rec_wish_{rec_pid}_{idx}", use_container_width=True):
                        toggle_wishlist(rec_pid)
                        st.rerun()

                st.markdown("<div style='margin-bottom:1rem;'></div>", unsafe_allow_html=True)


# ==========================================
# PAGE 3: PERSONALIZED "FOR YOU"
# ==========================================
elif st.session_state.active_nav == "👤 Personalized 'For You'":
    st.markdown("## 👤 Personalized Recommendations Engine")
    st.markdown(
        "Generates customized product suggestions based on user rating history, "
        "collaborative peer patterns, and content affinity."
    )

    col_u, col_settings = st.columns([2, 2])
    with col_u:
        active_user = st.session_state.current_user_id
        st.markdown(f"**Current Active User:** `{active_user}`")
        if active_user == "GUEST_COLD_START":
            st.warning("⚠️ You are simulating a **new guest user with no rating history** (Cold Start).")
        else:
            history = collab_engine.get_user_history(active_user)
            st.success(f"User has rated **{len(history)} products** in the database.")
            with st.expander("📜 View User's Past Rating History"):
                for h in history:
                    st.write(f"- **{h['name']}** ({h['category']}) -> Rated: ★ **{h['user_rating']}**")

    with col_settings:
        alpha_slider = st.slider(
            "Hybrid Fusion Weight (α):",
            min_value=0.0,
            max_value=1.0,
            value=0.55,
            step=0.05,
            help="α = 1.0 is pure Content-Based (text similarity). α = 0.0 is pure Collaborative Filtering (user-item ratings).",
        )
        st.caption(f"Score Formula: `Final = {alpha_slider:.2f} × Content + {1-alpha_slider:.2f} × Collaborative`")

    tab1, tab2, tab3 = st.tabs([
        "🔮 Hybrid Recommendations (Recommended)",
        "👥 Pure Collaborative Filtering (IBCF)",
        "📄 Pure Content Taste Profile",
    ])

    with tab1:
        st.markdown("### Top Hybrid Recommendations")
        # Gather user liked items if available
        user_liked = []
        if active_user != "GUEST_COLD_START":
            user_ratings = ratings_df[ratings_df["user_id"] == active_user]
            user_liked = user_ratings[user_ratings["rating"] >= 4.0]["product_id"].tolist()

        hybrid_recs = hybrid_engine.recommend(
            user_id=None if active_user == "GUEST_COLD_START" else active_user,
            user_liked_ids=user_liked,
            top_k=6,
            alpha=alpha_slider,
        )

        h_cols = st.columns(3)
        for i, rec in enumerate(hybrid_recs):
            with h_cols[i % 3]:
                st.markdown(
                    f"""
                    <div class="product-card">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span class="badge-category">{rec['category']}</span>
                            <span class="badge-match">{rec['match_percentage']} Hybrid</span>
                        </div>
                        <div class="badge-brand">{rec.get('brand', '')}</div>
                        <div class="product-title">{rec['name']}</div>
                        <div class="explanation-box">
                            <strong>Transparent Logic:</strong><br>{rec['explanation']}
                        </div>
                        <div class="product-desc">{rec['description']}</div>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:auto; padding-top:0.5rem;">
                            <span class="product-price">{format_currency(rec['price'])}</span>
                            <span class="product-rating">★ {rec['rating']:.1f}</span>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
                if st.button("Inspect Item", key=f"hyb_btn_{rec['product_id']}_{i}", use_container_width=True):
                    view_product_details(rec["product_id"])
                    st.rerun()
                st.markdown("<div style='margin-bottom:1rem;'></div>", unsafe_allow_html=True)

    with tab2:
        st.markdown("### Pure Collaborative Filtering Recommendations (Item-Based)")
        cf_recs = collab_engine.recommend_for_user(active_user, top_k=6)
        cf_cols = st.columns(3)
        for i, rec in enumerate(cf_recs):
            with cf_cols[i % 3]:
                st.markdown(
                    f"""
                    <div class="product-card">
                        <span class="badge-category">{rec['category']}</span>
                        <div class="badge-brand">{rec.get('brand', '')}</div>
                        <div class="product-title">{rec['name']}</div>
                        <div class="explanation-box">
                            {rec['explanation']}
                        </div>
                        <div class="product-desc">{rec['description']}</div>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:auto; padding-top:0.5rem;">
                            <span class="product-price">{format_currency(rec['price'])}</span>
                            <span class="product-rating">Predicted: ★ {rec['predicted_rating']}</span>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
                if st.button("Inspect Item", key=f"cf_btn_{rec['product_id']}_{i}", use_container_width=True):
                    view_product_details(rec["product_id"])
                    st.rerun()
                st.markdown("<div style='margin-bottom:1rem;'></div>", unsafe_allow_html=True)

    with tab3:
        st.markdown("### Content Taste Centroid Recommendations")
        if not user_liked:
            st.info("No positively rated items (★ ≥ 4.0) found for this user. Displaying popular fallback.")
            cnt_recs = content_engine.get_top_rated_fallback(top_k=6)
        else:
            cnt_recs = content_engine.recommend_for_profile(user_liked, top_k=6)

        cnt_cols = st.columns(3)
        for i, rec in enumerate(cnt_recs):
            with cnt_cols[i % 3]:
                st.markdown(
                    f"""
                    <div class="product-card">
                        <span class="badge-category">{rec['category']}</span>
                        <div class="badge-brand">{rec.get('brand', '')}</div>
                        <div class="product-title">{rec['name']}</div>
                        <div class="explanation-box">
                            {rec['explanation']}
                        </div>
                        <div class="product-desc">{rec['description']}</div>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:auto; padding-top:0.5rem;">
                            <span class="product-price">{format_currency(rec['price'])}</span>
                            <span class="product-rating">★ {rec['rating']:.1f}</span>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
                if st.button("Inspect Item", key=f"cnt_btn_{rec['product_id']}_{i}", use_container_width=True):
                    view_product_details(rec["product_id"])
                    st.rerun()
                st.markdown("<div style='margin-bottom:1rem;'></div>", unsafe_allow_html=True)


# ==========================================
# PAGE 4: MY WISHLIST
# ==========================================
elif st.session_state.active_nav == "💖 My Wishlist":
    st.markdown("## 💖 My Wishlist & Real-Time Profile Recommendations")
    st.markdown(
        "Items saved to your wishlist instantly update your taste vector, "
        "allowing the recommendation engine to tailor suggestions in real time."
    )

    wishlist_ids = st.session_state.wishlist

    if not wishlist_ids:
        st.info("Your wishlist is currently empty! Explore the storefront and click '🤍 Wishlist' on products you like.")
    else:
        st.markdown(f"### 📋 Saved Products ({len(wishlist_ids)})")
        w_cols = st.columns(3)
        for idx, wid in enumerate(wishlist_ids):
            prod = products_df[products_df["product_id"] == wid]
            if prod.empty:
                continue
            r = prod.iloc[0]

            with w_cols[idx % 3]:
                st.markdown(
                    f"""
                    <div class="product-card">
                        <span class="badge-category">{r['category']}</span>
                        <div class="badge-brand">{r.get('brand', '')}</div>
                        <div class="product-title">{r['name']}</div>
                        <div class="product-desc">{r['description']}</div>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:auto; padding-top:0.5rem;">
                            <span class="product-price">{format_currency(r['price'])}</span>
                            <span class="product-rating">★ {r['rating']:.1f}</span>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
                b1, b2 = st.columns([1, 1])
                with b1:
                    if st.button("Inspect", key=f"w_ins_{wid}", use_container_width=True):
                        view_product_details(wid)
                        st.rerun()
                with b2:
                    if st.button("Remove ❌", key=f"w_rem_{wid}", use_container_width=True):
                        toggle_wishlist(wid)
                        st.rerun()
                st.markdown("<div style='margin-bottom:1rem;'></div>", unsafe_allow_html=True)

        st.markdown("---")
        st.markdown("### 💡 Recommended Based on Your Wishlist")
        st.caption("Generated by calculating the centroid vector of your saved items across TF-IDF text features.")

        wishlist_recs = content_engine.recommend_for_profile(wishlist_ids, top_k=3, exclude_seen=True)
        r_cols = st.columns(3)
        for idx, rec in enumerate(wishlist_recs):
            with r_cols[idx % 3]:
                st.markdown(
                    f"""
                    <div class="product-card">
                        <div style="display:flex; justify-content:space-between; align-items:center;">
                            <span class="badge-category">{rec['category']}</span>
                            <span class="badge-match">{rec['match_percentage']}</span>
                        </div>
                        <div class="badge-brand">{rec.get('brand', '')}</div>
                        <div class="product-title">{rec['name']}</div>
                        <div class="explanation-box">{rec['explanation']}</div>
                        <div class="product-desc">{rec['description']}</div>
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:auto; padding-top:0.5rem;">
                            <span class="product-price">{format_currency(rec['price'])}</span>
                            <span class="product-rating">★ {rec['rating']:.1f}</span>
                        </div>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
                if st.button("Add to Wishlist ❤️", key=f"w_rec_add_{rec['product_id']}", use_container_width=True):
                    toggle_wishlist(rec["product_id"])
                    st.rerun()
                st.markdown("<div style='margin-bottom:1rem;'></div>", unsafe_allow_html=True)


# ==========================================
# PAGE 5: ML ANALYTICS & DASHBOARD
# ==========================================
elif st.session_state.active_nav == "📊 ML Analytics & Dashboard":
    st.markdown("## 📊 Machine Learning & E-Commerce Analytics Dashboard")
    st.markdown(
        "Interactive exploratory data analysis and mathematical insights into catalog distributions and recommendation spaces."
    )

    # Metric summary row
    m1, m2, m3, m4 = st.columns(4)
    with m1:
        st.markdown(
            f"""<div class="stat-card"><div class="stat-value">{dataset_summary['num_products']}</div><div class="stat-label">Catalog Products</div></div>""",
            unsafe_allow_html=True,
        )
    with m2:
        st.markdown(
            f"""<div class="stat-card"><div class="stat-value">{dataset_summary['num_categories']}</div><div class="stat-label">Categories</div></div>""",
            unsafe_allow_html=True,
        )
    with m3:
        st.markdown(
            f"""<div class="stat-card"><div class="stat-value">{dataset_summary['num_ratings']}</div><div class="stat-label">User Interactions</div></div>""",
            unsafe_allow_html=True,
        )
    with m4:
        st.markdown(
            f"""<div class="stat-card"><div class="stat-value">{dataset_summary['sparsity_percent']}%</div><div class="stat-label">Matrix Sparsity</div></div>""",
            unsafe_allow_html=True,
        )

    st.markdown("<div style='margin-top:1.5rem;'></div>", unsafe_allow_html=True)

    # Charts Row 1
    c1, c2 = st.columns(2)
    with c1:
        st.markdown("#### 📦 Product Category Distribution")
        fig, ax = plt.subplots(figsize=(6, 4))
        cat_counts = products_df["category"].value_counts()
        colors = plt.cm.viridis(np.linspace(0.2, 0.85, len(cat_counts)))
        ax.barh(cat_counts.index, cat_counts.values, color=colors)
        ax.set_xlabel("Number of Products")
        ax.set_title("Catalog Breakdown by Category", fontweight="bold")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close()

    with c2:
        st.markdown("#### ⭐ Product Ratings Distribution")
        fig, ax = plt.subplots(figsize=(6, 4))
        ax.hist(products_df["rating"], bins=8, color="#6366f1", edgecolor="#312e81", alpha=0.85)
        ax.set_xlabel("Star Rating (1.0 to 5.0)")
        ax.set_ylabel("Product Count")
        ax.set_title("Customer Rating Spread", fontweight="bold")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close()

    # Charts Row 2
    c3, c4 = st.columns(2)
    with c3:
        st.markdown("#### 💰 Average Price by Category")
        fig, ax = plt.subplots(figsize=(6, 4))
        cat_price = products_df.groupby("category")["price"].mean().sort_values()
        ax.bar(cat_price.index, cat_price.values, color="#0ea5e9", edgecolor="#0284c7")
        ax.set_ylabel(f"Avg Price ({CURRENCY_SYMBOL})")
        ax.set_title("Average Product Price by Department", fontweight="bold")
        plt.xticks(rotation=30, ha="right")
        ax.spines["top"].set_visible(False)
        ax.spines["right"].set_visible(False)
        plt.tight_layout()
        st.pyplot(fig)
        plt.close()

    with c4:
        st.markdown("#### 🔬 Content Cosine Similarity Heatmap (Sample)")
        sample_n = min(8, len(products_df))
        sample_sim = content_engine.similarity_matrix[:sample_n, :sample_n]
        sample_labels = [
            f"{products_df.iloc[i]['product_id']} ({products_df.iloc[i]['category'][:4]})"
            for i in range(sample_n)
        ]

        fig, ax = plt.subplots(figsize=(6, 4.2))
        sns.heatmap(
            sample_sim,
            xticklabels=sample_labels,
            yticklabels=sample_labels,
            cmap="mako",
            annot=True,
            fmt=".2f",
            cbar=True,
            ax=ax,
        )
        ax.set_title("TF-IDF Cosine Similarity Matrix (Top 8 Items)", fontweight="bold")
        plt.tight_layout()
        st.pyplot(fig)
        plt.close()


# ==========================================
# PAGE 6: OFFLINE MODEL EVALUATION
# ==========================================
elif st.session_state.active_nav == "🧪 Offline Model Evaluation":
    st.markdown("## 🧪 Offline Recommender Evaluation Benchmark")
    st.markdown(
        "Rigorous offline empirical evaluation using **Train/Test User Interaction Split**. "
        "Calculates Precision@K, Recall@K, Mean Reciprocal Rank (MRR), and Catalog Coverage."
    )

    ev_col1, ev_col2 = st.columns([2, 1])
    with ev_col1:
        st.markdown(
            """
            **Evaluation Methodology:**
            1. Partition ratings for each user with $\\ge 3$ interactions into **Train (75%)** and **Test (25%)**.
            2. Ground truth relevant items are defined as products in the user's test set with rating $\\ge 4.0$.
            3. Generate top-K recommendations using models trained only on the training partition.
            4. Measure how accurately each model predicts unseen test interactions.
            """
        )
    with ev_col2:
        k_eval = st.multiselect("Select K thresholds to evaluate:", options=[3, 5, 10], default=[3, 5])
        threshold_eval = st.slider("Relevance Rating Threshold:", min_value=3.0, max_value=5.0, value=4.0, step=0.5)

    if st.button("🚀 Run Live Evaluation Benchmark", type="primary"):
        with st.spinner("Computing train/test splits, generating recommendations, and computing metrics..."):
            eval_data = evaluate_recommenders(
                products_df, ratings_df, k_values=k_eval, relevance_threshold=threshold_eval
            )

        if "error" in eval_data:
            st.error(eval_data["error"])
        else:
            st.success(
                f"Benchmark complete! Evaluated across {eval_data['num_eval_users']} users and "
                f"{eval_data['num_test_interactions']} test interactions."
            )

            # Build comparative DataFrame
            table_rows = []
            for model_name, k_dict in eval_data["models"].items():
                for k_key, metrics in k_dict.items():
                    table_rows.append(
                        {
                            "Model": model_name,
                            "Metric Cutoff": k_key,
                            "Precision@K": f"{metrics['Precision']:.4f}",
                            "Recall@K": f"{metrics['Recall']:.4f}",
                            "F1-Score@K": f"{metrics['F1_Score']:.4f}",
                            "MRR@K": f"{metrics['MRR']:.4f}",
                            "Coverage (%)": f"{metrics['Coverage_Pct']:.1f}%",
                        }
                    )

            res_df = pd.DataFrame(table_rows)
            st.dataframe(res_df, use_container_width=True)

            # Precision/Recall Comparative Plot
            st.markdown("#### 📈 Model Comparison Charts")
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(10, 4))

            k_label = f"K={k_eval[0]}" if k_eval else "K=3"
            models = list(eval_data["models"].keys())
            precisions = [eval_data["models"][m].get(k_label, {}).get("Precision", 0) for m in models]
            recalls = [eval_data["models"][m].get(k_label, {}).get("Recall", 0) for m in models]

            colors = ["#3b82f6", "#10b981", "#8b5cf6"]
            ax1.bar(models, precisions, color=colors)
            ax1.set_title(f"Precision@{k_label}", fontweight="bold")
            ax1.set_ylabel("Precision")
            ax1.spines["top"].set_visible(False)
            ax1.spines["right"].set_visible(False)

            ax2.bar(models, recalls, color=colors)
            ax2.set_title(f"Recall@{k_label}", fontweight="bold")
            ax2.set_ylabel("Recall")
            ax2.spines["top"].set_visible(False)
            ax2.spines["right"].set_visible(False)

            plt.tight_layout()
            st.pyplot(fig)
            plt.close()


# ==========================================
# PAGE 7: B.TECH VIVA VOCE & PROJECT GUIDE
# ==========================================
elif st.session_state.active_nav == "🎓 B.Tech Viva Voce & Guide":
    st.markdown("## 🎓 B.Tech 3rd-Year AIML Viva Voce & Presentation Guide")
    st.markdown(
        "Comprehensive architectural breakdown, mathematical formulations, and answers to expected external examiner questions."
    )

    tab_arch, tab_math, tab_viva = st.tabs([
        "🏗️ System Architecture",
        "📐 Mathematical Formulations",
        "❓ Viva Voce Q&A",
    ])

    with tab_arch:
        st.markdown(
            """
            ### System Pipeline Architecture
            
            ```
            [ Raw Product Catalog (CSV) ]         [ User Rating Interactions (CSV) ]
                          │                                         │
                          ▼                                         ▼
            [ Data Cleaning & Imputation ]         [ Matrix Sparsity Sanitization ]
                          │                                         │
                          ▼                                         ▼
            [ Text Soup Construction ]             [ User-Item Rating Matrix ]
            (Name + Category + Brand + Tags)                        │
                          │                                         ▼
                          ▼                         [ Item-Item / User-User Cosine ]
            [ TF-IDF Vectorization ]                                │
            (N-grams (1,2), Stopwords)                              ▼
                          │                        [ Collaborative Rating Prediction ]
                          ▼                        [ r_hat(u, i) / 5.0 (Normalized) ]
            [ Content Cosine Similarity ]                           │
            [ Cosine Sim(v_i, v_j) ]                               │
                          │                                         │
                          └───────────────────┬─────────────────────┘
                                              │
                                              ▼
                                 [ Adaptive Hybrid Engine ]
                      Score = α · S_content + (1 - α) · S_collab
                      (Dynamic α = 1.0 for cold-start users)
                                              │
                                              ▼
                                 [ Streamlit UI Presentation ]
                    (Storefront, Wishlist, Analytics, Explanations)
            ```
            """
        )

    with tab_math:
        st.markdown(
            r"""
            ### 1. Term Frequency - Inverse Document Frequency (TF-IDF)
            The term frequency-inverse document frequency weight for term $t$ in product document $d$:
            $$\text{TF}(t, d) = \frac{\text{count}(t \in d)}{\text{total words in } d}$$
            $$\text{IDF}(t) = \ln\left(\frac{1 + N}{1 + \text{DF}(t)}\right) + 1$$
            $$\text{TF-IDF}(t, d) = \text{TF}(t, d) \times \text{IDF}(t)$$

            ### 2. Cosine Similarity
            Measures cosine of the angle between two feature vectors $\mathbf{u}$ and $\mathbf{v}$:
            $$\text{Cosine Similarity}(\mathbf{u}, \mathbf{v}) = \frac{\mathbf{u} \cdot \mathbf{v}}{\|\mathbf{u}\|_2 \|\mathbf{v}\|_2} = \frac{\sum_{i=1}^n u_i v_i}{\sqrt{\sum_{i=1}^n u_i^2} \sqrt{\sum_{i=1}^n v_i^2}}$$

            ### 3. Item-Based Collaborative Filtering Rating Prediction
            Predicts user $u$'s rating for item $i$ as a weighted average of ratings on similar items $j$:
            $$\hat{r}(u, i) = \frac{\sum_{j \in \text{Rated}(u)} \text{sim}(i, j) \cdot r(u, j)}{\sum_{j \in \text{Rated}(u)} |\text{sim}(i, j)|}$$

            ### 4. Hybrid Linear Combination
            $$\text{Score}_{hybrid}(u, i) = \alpha \cdot S_{content}(u, i) + (1 - \alpha) \cdot \frac{\hat{r}(u, i)}{5.0}$$
            where $\alpha \in [0, 1]$ balances content semantics against community preferences.
            """
        )

    with tab_viva:
        viva_qa = [
            (
                "Q1. What is the fundamental difference between Content-Based and Collaborative Filtering?",
                "Content-Based filtering relies strictly on item attributes and descriptions (TF-IDF features). It recommends items similar to what the user liked in the past without requiring other users' data. Collaborative Filtering relies on collective community rating patterns (wisdom of the crowd) to find similar users or items regardless of metadata.",
            ),
            (
                "Q2. How does this project solve the Cold-Start Problem?",
                "The project addresses cold start at two levels: (1) New users with no ratings automatically have the hybrid weight dynamically adjusted (α = 1.0) to rely on active session browsing or wishlist items. (2) Pure cold-start visitors with zero history receive popularity and Bayesian top-rated fallback recommendations in each category.",
            ),
            (
                "Q3. Why is TF-IDF preferred over simple Word Count for product recommendations?",
                "Word Count counts all words equally, heavily skewing towards common stopwords and generic words like 'product', 'design', or 'quality'. TF-IDF penalizes words that appear across all documents and boosts rare, highly informative keywords like 'noise-cancelling', 'mechanical', or 'espresso'.",
            ),
            (
                "Q4. What is User-Item Matrix Sparsity and why does it matter?",
                "In real-world e-commerce, any single user only rates a tiny fraction of total products, leading to a matrix that is 85-99% empty (sparse). High sparsity degrades collaborative filtering accuracy because user overlap is minimal. Our hybrid architecture compensates by filling sparse signals with dense content vectors.",
            ),
            (
                "Q5. How do you evaluate recommendation systems offline?",
                "We use Precision@K, Recall@K, and Mean Reciprocal Rank (MRR@K) by splitting user interaction histories into train and test sets. Precision@K measures what proportion of the top-K recommendations were actually relevant to the user, while Recall@K measures what fraction of all relevant items were successfully retrieved.",
            ),
        ]

        for q, a in viva_qa:
            st.markdown(
                f"""
                <div class="viva-box">
                    <div class="viva-q">{q}</div>
                    <div class="viva-a">{a}</div>
                </div>
                """,
                unsafe_allow_html=True,
            )
