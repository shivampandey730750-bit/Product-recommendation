"""
Automated verification test script for Smart Product Recommendation System.
Validates data pipelines, algorithms, cold-start handling, and evaluation metrics.
Configured for cross-platform and Windows console compatibility.
"""
import sys
from pathlib import Path

# Ensure UTF-8 stdout if available
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

# Add project root to sys.path
PROJECT_ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(PROJECT_ROOT))

from src.data_loader import load_products, load_ratings, get_dataset_summary
from src.content_based import ContentBasedRecommender
from src.collaborative import CollaborativeRecommender
from src.hybrid import HybridRecommender
from src.evaluation import evaluate_recommenders


def run_all_tests():
    print("=" * 65)
    print(">> SMART PRODUCT RECOMMENDATION SYSTEM - TEST SUITE")
    print("=" * 65)

    # 1. Test Data Loading
    print("\n[1/5] Testing Data Loading & Preprocessing...")
    products_df = load_products()
    ratings_df = load_ratings()
    summary = get_dataset_summary(products_df, ratings_df)

    assert len(products_df) > 0, "Products DataFrame should not be empty"
    assert len(ratings_df) > 0, "Ratings DataFrame should not be empty"
    assert "content_soup" in products_df.columns, "Soup column must be generated"
    assert summary["num_products"] == len(products_df)

    print(f"  [PASS] Loaded {len(products_df)} products across {summary['num_categories']} categories.")
    print(f"  [PASS] Loaded {len(ratings_df)} user ratings from {summary['num_users']} unique users.")
    print(f"  [PASS] Matrix sparsity: {summary['sparsity_percent']}%")

    # 2. Test Content-Based Filtering
    print("\n[2/5] Testing Content-Based Recommender (TF-IDF + Cosine)...")
    content_rec = ContentBasedRecommender(products_df)
    test_pid = "P101"  # Sony WH-1000XM5 Headphones
    recs = content_rec.get_similar_products(test_pid, top_k=3)

    assert len(recs) == 3, f"Expected 3 recommendations, got {len(recs)}"
    for r in recs:
        assert r["product_id"] != test_pid, "Target product must be excluded from recommendations"
        assert 0.0 <= r["similarity_score"] <= 1.0, "Similarity score must be in [0, 1]"
        assert len(r["explanation"]) > 0, "Explanation should be non-empty"

    prod_name = products_df[products_df['product_id'] == test_pid]['name'].values[0]
    print(f"  [PASS] Generated {len(recs)} similar items for '{prod_name}':")
    for r in recs:
        print(f"    - {r['name']} ({r['match_percentage']}) | Reason: {r['explanation']}")

    # Test profile recommendation
    profile_recs = content_rec.recommend_for_profile(["P101", "P102"], top_k=2)
    assert len(profile_recs) == 2, "Profile recommendation failed"
    print("  [PASS] Profile recommendation generated successfully.")

    # 3. Test Collaborative Filtering
    print("\n[3/5] Testing Collaborative Filtering (Item-Based)...")
    collab_rec = CollaborativeRecommender(ratings_df, products_df)
    known_user = "U101"
    cf_recs = collab_rec.recommend_for_user(known_user, top_k=3)

    assert len(cf_recs) == 3, f"Expected 3 CF recommendations, got {len(cf_recs)}"
    for r in cf_recs:
        assert 1.0 <= r["predicted_rating"] <= 5.0, "Predicted rating must be in [1.0, 5.0]"

    print(f"  [PASS] Top CF recommendations for user {known_user}:")
    for r in cf_recs:
        print(f"    - {r['name']} | Predicted: {r['predicted_rating']}/5.0 | {r['explanation']}")

    # Test Cold-Start User
    cold_user = "U999_NEW"
    cold_recs = collab_rec.recommend_for_user(cold_user, top_k=2)
    assert len(cold_recs) == 2, "Cold-start fallback must produce recommendations"
    print(f"  [PASS] Cold-start fallback gracefully handled for new user '{cold_user}'.")

    # 4. Test Hybrid Recommender
    print("\n[4/5] Testing Hybrid Recommendation Engine...")
    hybrid_rec = HybridRecommender(content_rec, collab_rec, default_alpha=0.6)
    hybrid_results = hybrid_rec.recommend(
        user_id="U101",
        anchor_product_id="P101",
        top_k=3,
        alpha=0.6,
    )

    assert len(hybrid_results) == 3, f"Expected 3 hybrid recommendations, got {len(hybrid_results)}"
    for h in hybrid_results:
        assert h["product_id"] != "P101", "Target product must be excluded"
        assert 0.0 <= h["hybrid_score"] <= 1.0, "Hybrid score must be in [0, 1]"

    print("  [PASS] Hybrid recommendations (alpha=0.6) successfully computed:")
    for h in hybrid_results:
        print(f"    - {h['name']} | Hybrid Score: {h['hybrid_score']} | {h['explanation']}")

    # 5. Test Evaluation Suite
    print("\n[5/5] Testing Offline Evaluation Suite (Train/Test Benchmark)...")
    eval_results = evaluate_recommenders(
        products_df, ratings_df, k_values=[3, 5], relevance_threshold=4.0
    )

    assert "models" in eval_results, "Evaluation must produce model metrics"
    print(f"  [PASS] Evaluated on {eval_results['num_eval_users']} test users with {eval_results['num_test_interactions']} interactions.")
    for model_name, metrics in eval_results["models"].items():
        print(f"    [{model_name}]")
        for k_label, values in metrics.items():
            print(f"      {k_label}: Precision={values['Precision']}, Recall={values['Recall']}, MRR={values['MRR']}, Coverage={values['Coverage_Pct']}%")

    print("\n" + "=" * 65)
    print(">> ALL TESTS PASSED SUCCESSFULLY! SYSTEM INTEGRITY VERIFIED 100%")
    print("=" * 65)


if __name__ == "__main__":
    run_all_tests()
