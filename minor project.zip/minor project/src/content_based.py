"""
Content-Based Recommendation Engine using TF-IDF and Cosine Similarity.
Provides single-product similarity recommendations and multi-product profile recommendations
with clear, student-friendly explanation generation.
"""
from typing import List, Dict, Any, Optional
import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from src.config import (
    TFIDF_MAX_FEATURES,
    TFIDF_STOP_WORDS,
    TFIDF_NGRAM_RANGE,
    DEFAULT_TOP_K,
    MIN_SIMILARITY_THRESHOLD,
)


class ContentBasedRecommender:
    """
    TF-IDF Vectorizer + Cosine Similarity Recommender.
    Computes text feature vectors across product names, categories, tags, and descriptions.
    """

    def __init__(self, products_df: pd.DataFrame):
        self.df = products_df.copy().reset_index(drop=True)
        # Create map from product_id to matrix row index
        self.id_to_idx = {row["product_id"]: idx for idx, row in self.df.iterrows()}
        self.idx_to_id = {idx: row["product_id"] for idx, row in self.df.iterrows()}

        self.vectorizer = TfidfVectorizer(
            max_features=TFIDF_MAX_FEATURES,
            stop_words=TFIDF_STOP_WORDS,
            ngram_range=TFIDF_NGRAM_RANGE,
        )

        # Fit vectorizer and compute cosine similarity matrix
        self.tfidf_matrix = self.vectorizer.fit_transform(self.df["content_soup"])
        self.similarity_matrix = cosine_similarity(self.tfidf_matrix, self.tfidf_matrix)
        self.feature_names = np.array(self.vectorizer.get_feature_names_out())

    def get_similar_products(
        self,
        product_id: str,
        top_k: int = DEFAULT_TOP_K,
        category_filter: Optional[str] = None,
        max_price: Optional[float] = None,
    ) -> List[Dict[str, Any]]:
        """
        Recommend top-K products similar to the given product_id.
        Excludes the selected product itself.
        """
        if product_id not in self.id_to_idx:
            return []

        target_idx = self.id_to_idx[product_id]
        target_product = self.df.iloc[target_idx]

        # Get similarity scores for all items relative to target
        sim_scores = list(enumerate(self.similarity_matrix[target_idx]))

        # Sort descending by similarity score
        sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)

        recommendations = []
        for idx, score in sim_scores:
            # Exclude target product itself
            if idx == target_idx:
                continue

            row = self.df.iloc[idx]

            # Optional category and price filtering
            if category_filter and row["category"].lower() != category_filter.lower():
                continue
            if max_price is not None and row["price"] > max_price:
                continue

            explanation = self._generate_explanation(target_product, row, score)

            recommendations.append(
                {
                    "product_id": row["product_id"],
                    "name": row["name"],
                    "category": row["category"],
                    "subcategory": row["subcategory"],
                    "brand": row["brand"],
                    "price": row["price"],
                    "rating": row["rating"],
                    "rating_count": row["rating_count"],
                    "image_url": row["image_url"],
                    "description": row["description"],
                    "similarity_score": round(float(score), 4),
                    "match_percentage": f"{int(round(score * 100))}%",
                    "explanation": explanation,
                }
            )

            if len(recommendations) >= top_k:
                break

        return recommendations

    def recommend_for_profile(
        self,
        liked_product_ids: List[str],
        top_k: int = DEFAULT_TOP_K,
        exclude_seen: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        Recommend products based on an aggregate profile of multiple liked / wishlisted items.
        Synthesizes a centroid vector in the TF-IDF space and computes cosine similarity.
        """
        valid_indices = [
            self.id_to_idx[pid] for pid in liked_product_ids if pid in self.id_to_idx
        ]

        if not valid_indices:
            # Fallback to top-rated items if no valid history
            return self.get_top_rated_fallback(top_k=top_k)

        # Compute centroid vector for the user profile
        user_vector = np.asarray(self.tfidf_matrix[valid_indices].mean(axis=0))
        scores = cosine_similarity(user_vector, self.tfidf_matrix)[0]

        scored_indices = list(enumerate(scores))
        scored_indices = sorted(scored_indices, key=lambda x: x[1], reverse=True)

        recommendations = []
        for idx, score in scored_indices:
            pid = self.idx_to_id[idx]
            if exclude_seen and pid in liked_product_ids:
                continue

            row = self.df.iloc[idx]
            match_pct = f"{int(round(score * 100))}%"
            explanation = (
                f"Matches your taste profile based on your interest in "
                f"{len(valid_indices)} saved items ({row['category']} - {row['brand']})."
            )

            recommendations.append(
                {
                    "product_id": row["product_id"],
                    "name": row["name"],
                    "category": row["category"],
                    "subcategory": row["subcategory"],
                    "brand": row["brand"],
                    "price": row["price"],
                    "rating": row["rating"],
                    "rating_count": row["rating_count"],
                    "image_url": row["image_url"],
                    "description": row["description"],
                    "similarity_score": round(float(score), 4),
                    "match_percentage": match_pct,
                    "explanation": explanation,
                }
            )

            if len(recommendations) >= top_k:
                break

        return recommendations

    def get_top_rated_fallback(self, top_k: int = DEFAULT_TOP_K) -> List[Dict[str, Any]]:
        """Fallback recommendation returning top-rated popular products for cold-start."""
        sorted_df = self.df.sort_values(
            by=["rating", "rating_count"], ascending=[False, False]
        ).head(top_k)

        results = []
        for _, row in sorted_df.iterrows():
            results.append(
                {
                    "product_id": row["product_id"],
                    "name": row["name"],
                    "category": row["category"],
                    "subcategory": row["subcategory"],
                    "brand": row["brand"],
                    "price": row["price"],
                    "rating": row["rating"],
                    "rating_count": row["rating_count"],
                    "image_url": row["image_url"],
                    "description": row["description"],
                    "similarity_score": 0.0,
                    "match_percentage": "Popular",
                    "explanation": f"Trending top-rated item in {row['category']} with ★ {row['rating']} stars.",
                }
            )
        return results

    def _generate_explanation(
        self, target: pd.Series, candidate: pd.Series, score: float
    ) -> str:
        """Generate human-understandable explanation why product was recommended."""
        reasons = []

        if target["category"] == candidate["category"]:
            if target["subcategory"] == candidate["subcategory"]:
                reasons.append(f"Same subcategory ({candidate['subcategory']})")
            else:
                reasons.append(f"Same department ({candidate['category']})")

        if target["brand"] == candidate["brand"]:
            reasons.append(f"Same brand ({candidate['brand']})")

        # Find overlapping keywords from TF-IDF vectors
        target_idx = self.id_to_idx[target["product_id"]]
        cand_idx = self.id_to_idx[candidate["product_id"]]

        t_vec = self.tfidf_matrix[target_idx].toarray()[0]
        c_vec = self.tfidf_matrix[cand_idx].toarray()[0]
        shared_product = t_vec * c_vec
        top_shared_indices = np.argsort(shared_product)[::-1][:3]
        shared_terms = [
            self.feature_names[i]
            for i in top_shared_indices
            if shared_product[i] > 0.01
        ]

        if shared_terms:
            terms_str = ", ".join(shared_terms)
            reasons.append(f"Shared features: {terms_str}")

        if not reasons:
            reasons.append("High contextual text similarity")

        return f"{int(round(score * 100))}% match • " + " • ".join(reasons)
