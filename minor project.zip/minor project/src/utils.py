"""
UI styling and presentation utilities for Streamlit e-commerce application.
Provides custom CSS injection, star rendering, currency formatting, and card generators.
"""
from typing import Optional
import streamlit as st

from src.config import CURRENCY_SYMBOL, FALLBACK_IMAGE_URL


def format_currency(price: float) -> str:
    """Format floating point price into currency string."""
    return f"{CURRENCY_SYMBOL}{price:,.2f}"


def render_stars(rating: float) -> str:
    """Generate visual star representation for a rating out of 5."""
    full_stars = int(rating)
    half_star = 1 if (rating - full_stars) >= 0.5 else 0
    empty_stars = 5 - full_stars - half_star
    return "★" * full_stars + ("½" if half_star else "") + "☆" * empty_stars


def inject_custom_css():
    """Inject modern, responsive styling into Streamlit app."""
    custom_css = """
    <style>
    /* Google Fonts */
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap');

    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', sans-serif;
    }

    /* Main Container Padding */
    .block-container {
        padding-top: 1.5rem;
        padding-bottom: 3rem;
    }

    /* Hero Banner */
    .hero-banner {
        background: linear-gradient(135deg, #0f172a 0%, #1e293b 50%, #312e81 100%);
        color: #ffffff;
        padding: 2.2rem 2.4rem;
        border-radius: 18px;
        margin-bottom: 2rem;
        box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.25);
        border: 1px solid rgba(255, 255, 255, 0.1);
    }
    .hero-title {
        font-size: 2.2rem;
        font-weight: 800;
        margin-bottom: 0.4rem;
        background: linear-gradient(90deg, #38bdf8, #818cf8, #c084fc);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
    }
    .hero-subtitle {
        font-size: 1.05rem;
        color: #cbd5e1;
        margin-bottom: 0;
    }

    /* Stat Cards */
    .stat-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 14px;
        padding: 1.2rem;
        text-align: center;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.05);
        transition: transform 0.2s ease, box-shadow 0.2s ease;
    }
    .stat-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.08);
    }
    .stat-value {
        font-size: 1.8rem;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 0.2rem;
    }
    .stat-label {
        font-size: 0.85rem;
        color: #64748b;
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    /* Product Card Styling */
    .product-card {
        background: #ffffff;
        border: 1px solid #e2e8f0;
        border-radius: 16px;
        overflow: hidden;
        padding: 1.2rem;
        display: flex;
        flex-direction: column;
        height: 100%;
        box-shadow: 0 4px 10px rgba(0, 0, 0, 0.04);
        transition: all 0.25s ease-in-out;
        position: relative;
    }
    .product-card:hover {
        transform: translateY(-4px);
        box-shadow: 0 16px 30px rgba(0, 0, 0, 0.1);
        border-color: #cbd5e1;
    }

    /* Badges */
    .badge-category {
        display: inline-block;
        background-color: #e0e7ff;
        color: #4338ca;
        padding: 0.25rem 0.65rem;
        font-size: 0.72rem;
        font-weight: 700;
        border-radius: 9999px;
        text-transform: uppercase;
        letter-spacing: 0.04em;
        margin-bottom: 0.5rem;
    }
    .badge-match {
        display: inline-block;
        background: linear-gradient(135deg, #10b981 0%, #059669 100%);
        color: #ffffff;
        padding: 0.25rem 0.65rem;
        font-size: 0.75rem;
        font-weight: 700;
        border-radius: 9999px;
        margin-bottom: 0.5rem;
    }
    .badge-brand {
        color: #64748b;
        font-size: 0.8rem;
        font-weight: 600;
        margin-bottom: 0.2rem;
    }

    /* Typography inside cards */
    .product-title {
        font-size: 1.05rem;
        font-weight: 700;
        color: #0f172a;
        margin-bottom: 0.4rem;
        line-height: 1.35;
        min-height: 2.7rem;
    }
    .product-desc {
        font-size: 0.85rem;
        color: #475569;
        margin-bottom: 0.8rem;
        line-height: 1.4;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        overflow: hidden;
    }
    .product-price {
        font-size: 1.35rem;
        font-weight: 800;
        color: #0f172a;
    }
    .product-rating {
        color: #f59e0b;
        font-size: 0.9rem;
        font-weight: 600;
    }

    /* Explanation Box */
    .explanation-box {
        background-color: #f8fafc;
        border-left: 3px solid #6366f1;
        padding: 0.65rem 0.85rem;
        border-radius: 6px;
        font-size: 0.8rem;
        color: #334155;
        margin: 0.6rem 0;
        line-height: 1.35;
    }

    /* Modal / Detail Banner */
    .detail-container {
        background: #ffffff;
        border-radius: 16px;
        border: 1px solid #e2e8f0;
        padding: 1.5rem;
        box-shadow: 0 4px 12px rgba(0,0,0,0.05);
        margin-bottom: 1.5rem;
    }

    /* Section Headers */
    .section-header {
        font-size: 1.4rem;
        font-weight: 700;
        color: #0f172a;
        margin: 1.5rem 0 1rem 0;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    /* Viva Box */
    .viva-box {
        background: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 12px;
        padding: 1.2rem;
        margin-bottom: 1rem;
    }
    .viva-q {
        font-weight: 700;
        color: #1e1b4b;
        font-size: 1rem;
        margin-bottom: 0.4rem;
    }
    .viva-a {
        color: #334155;
        font-size: 0.92rem;
        line-height: 1.5;
    }
    </style>
    """
    st.markdown(custom_css, unsafe_allow_html=True)
