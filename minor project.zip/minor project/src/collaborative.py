"""
Collaborative Filtering Recommendation Engine.
Implements User-Based and Item-Based collaborative filtering using user-item interaction matrices,
cosine similarity, and rating normalization. Handles cold-start users with fallback strategies.
"""
from typing import List, Dict, Any, Optional, Tuple
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

from src.config import DEFAULT_TOP_K, MIN_COLLABORATIVE_RATINGS


class CollaborativeRecommender:
    """
    Item-Based and User-Based Collaborative Filtering Recommender.
    Constructs a user-item rating matrix and computes collaborative similarity scores.
    """

    def __init__(self, ratings_df: pd.DataFrame, products_df: pd.DataFrame):
        self.ratings_df = ratings_df.copy()
        self.products_df = products_df.copy()
        self.products_map = {
            row["product_id"]: row for _, row in self.products_df.iterrows()
        }

        # Build User-Item Matrix: rows = users, cols = products
        if not self.ratings_df.empty:
            self.user_item_matrix = self.ratings_df.pivot_table(
                index="user_id", columns="product_id", values="rating"
            ).fillna(0.0)
            self.users = list(self.user_item_matrix.index)
            self.items = list(self.user_item_matrix.columns)

            # Compute Item-Item similarity matrix (columns)
            item_matrix = self.user_item_matrix.T.values
            self.item_similarity = cosine_similarity(item_matrix, item_matrix)
            self.item_to_idx = {item: i for i, item in enumerate(self.items)}
            self.idx_to_item = {i: item for i, item in enumerate(self.items)}

            # Compute User-User similarity matrix (rows)
            user_matrix = self.user_item_matrix.values
            self.user_similarity = cosine_similarity(user_matrix, user_matrix)
            self.user_to_idx = {user: i for i, user in enumerate(self.users)}
        else:
            self.user_item_matrix = pd.DataFrame()
            self.users = []
            self.items = []
            self.item_similarity = np.array([[]])
            self.user_similarity = np.array([[]])
            self.item_to_idx = {}
            self.idx_to_item = {}
            self.user_to_idx = {}

    def get_known_users(self) -> List[str]:
        """Return list of user IDs present in the ratings dataset."""
        return sorted(self.users)

    def is_cold_start_user(self, user_id: str) -> bool:
        """Check if user is missing or has fewer than threshold interactions."""
        if user_id not in self.user_to_idx:
            return True
        user_ratings = self.user_item_matrix.loc[user_id]
        return (user_ratings > 0).sum() < MIN_COLLABORATIVE_RATINGS

    def predict_rating_item_based(self, user_id: str, product_id: str) -> float:
        """
        Predict rating using Item-Based Collaborative Filtering:
        r_hat(u, i) = sum(sim(i, j) * r(u, j)) / sum(|sim(i, j)|)
        """
        if (
            user_id not in self.user_to_idx
            or product_id not in self.item_to_idx
        ):
            # Fallback to product average rating
            prod = self.products_map.get(product_id)
            return float(prod["rating"]) if prod is not None else 3.5

        p_idx = self.item_to_idx[product_id]
        user_ratings = self.user_item_matrix.loc[user_id].values

        sim_vector = self.item_similarity[p_idx]
        rated_mask = user_ratings > 0

        if not np.any(rated_mask):
            prod = self.products_map.get(product_id)
            return float(prod["rating"]) if prod is not None else 3.5

        relevant_sims = sim_vector[rated_mask]
        relevant_ratings = user_ratings[rated_mask]

        sim_sum = np.sum(np.abs(relevant_sims))
        if sim_sum < 1e-5:
            prod = self.products_map.get(product_id)
            return float(prod["rating"]) if prod is not None else 3.5

        predicted_rating = float(np.sum(relevant_sims * relevant_ratings) / sim_sum)
        return float(np.clip(predicted_rating, 1.0, 5.0))

    def recommend_for_user(
        self,
        user_id: str,
        top_k: int = DEFAULT_TOP_K,
        exclude_rated: bool = True,
    ) -> List[Dict[str, Any]]:
        """
        Generate personalized collaborative filtering recommendations for a specific user.
        If user is cold-start, falls back to highest-rated popular items.
        """
        if self.is_cold_start_user(user_id):
            return self._cold_start_fallback(user_id, top_k)

        u_idx = self.user_to_idx[user_id]
        user_ratings = self.user_item_matrix.loc[user_id]
        rated_pids = set(user_ratings[user_ratings > 0].index)

        # Predict ratings for all items
        candidates = []
        for pid in self.products_map.keys():
            if exclude_rated and pid in rated_pids:
                continue

            pred_score = self.predict_rating_item_based(user_id, pid)
            candidates.append((pid, pred_score))

        # Sort descending by predicted score
        candidates = sorted(candidates, key=lambda x: x[1], reverse=True)

        recommendations = []
        for pid, score in candidates[:top_k]:
            prod = self.products_map.get(pid)
            if prod is None:
                continue

            explanation = (
                f"Predicted rating ★ {score:.1f}/5.0 based on common preferences of "
                f"users with taste similar to yours."
            )

            recommendations.append(
                {
                    "product_id": pid,
                    "name": prod["name"],
                    "category": prod["category"],
                    "subcategory": prod.get("subcategory", ""),
                    "brand": prod.get("brand", ""),
                    "price": prod["price"],
                    "rating": prod["rating"],
                    "rating_count": prod["rating_count"],
                    "image_url": prod["image_url"],
                    "description": prod["description"],
                    "predicted_rating": round(score, 2),
                    "normalized_cf_score": round(score / 5.0, 4),
                    "explanation": explanation,
                }
            )

        return recommendations

    def _cold_start_fallback(self, user_id: str, top_k: int) -> List[Dict[str, Any]]:
        """Fallback for cold-start users: returns top rated community favorites."""
        top_items = self.products_df.sort_values(
            by=["rating", "rating_count"], ascending=[False, False]
        ).head(top_k)

        recommendations = []
        for _, row in top_items.iterrows():
            recommendations.append(
                {
                    "product_id": row["product_id"],
                    "name": row["name"],
                    "category": row["category"],
                    "subcategory": row.get("subcategory", ""),
                    "brand": row.get("brand", ""),
                    "price": row["price"],
                    "rating": row["rating"],
                    "rating_count": row["rating_count"],
                    "image_url": row["image_url"],
                    "description": row["description"],
                    "predicted_rating": row["rating"],
                    "normalized_cf_score": round(row["rating"] / 5.0, 4),
                    "explanation": f"Cold-start fallback: Top community trending favorite in {row['category']}.",
                }
            )
        return recommendations

    def get_user_history(self, user_id: str) -> List[Dict[str, Any]]:
        """Retrieve rated items history for a user."""
        if self.ratings_df.empty or user_id not in self.ratings_df["user_id"].values:
            return []

        user_rows = self.ratings_df[self.ratings_df["user_id"] == user_id]
        history = []
        for _, r in user_rows.iterrows():
            prod = self.products_map.get(r["product_id"])
            if prod is not None:
                history.append(
                    {
                        "product_id": r["product_id"],
                        "name": prod["name"],
                        "category": prod["category"],
                        "brand": prod.get("brand", ""),
                        "user_rating": r["rating"],
                        "image_url": prod["image_url"],
                        "price": prod["price"],
                    }
                )
        return history
