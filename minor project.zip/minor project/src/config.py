"""
Configuration settings for Smart Product Recommendation System.
Defines relative paths, model hyperparameters, and UI defaults.
"""
from pathlib import Path

# Base Paths (dynamically resolved)
BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"

PRODUCTS_DATA_PATH = DATA_DIR / "products.csv"
RATINGS_DATA_PATH = DATA_DIR / "user_ratings.csv"

# Model Hyperparameters
TFIDF_MAX_FEATURES = 5000
TFIDF_STOP_WORDS = "english"
TFIDF_NGRAM_RANGE = (1, 2)

# Hybrid Weighting
# score = alpha * content_score + (1 - alpha) * collaborative_score
DEFAULT_HYBRID_ALPHA = 0.55

# Recommendation Settings
DEFAULT_TOP_K = 5
MIN_SIMILARITY_THRESHOLD = 0.05
MIN_COLLABORATIVE_RATINGS = 2

# Fallback Image for unavailable or failed image links
FALLBACK_IMAGE_URL = (
    "https://images.unsplash.com/photo-1526170375885-4d8ecf77b99f?w=600&auto=format&fit=crop&q=80"
)

# App UI Settings
CURRENCY_SYMBOL = "$"
APP_TITLE = "Smart Product Recommendation System"
APP_SUBTITLE = "AIML-Powered Intelligent E-Commerce Discovery Engine"
