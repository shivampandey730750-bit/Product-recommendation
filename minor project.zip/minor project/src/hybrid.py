"""
Hybrid Recommendation Engine.
Fuses Content-Based text similarity (TF-IDF + Cosine) and Collaborative Filtering ratings
using a parameterized linear combination with adaptive cold-start weights.
"""
from typing import List, Dict, Any, Optional
import numpy as np
import pandas as pd

from src.content_based import ContentBasedRecommender
from src.collaborative import CollaborativeRecommender
from src.config import DEFAULT_TOP_K, DEFAULT_HYBRID_ALPHA


class HybridRecommender:
    """
    Weighted Linear Hybrid Recommender:
    Final Score = alpha * Content_Score + (1 - alpha) * Collaborative_Score
    """

    def __init__(
        self,
        content_engine: ContentBasedRecommender,
        collab_engine: CollaborativeRecommender,
        default_alpha: float = DEFAULT_HYBRID_ALPHA,
    ):
        self.content_engine = content_engine
        self.collab_engine = collab_engine
        self.default_alpha = float(np.clip(default_alpha, 0.0, 1.0))
        self.products_df = content_engine.df
        self.products_map = {
            row["product_id"]: row for _, row in self.products_df.iterrows()
        }

    def recommend(
        self,
        user_id: Optional[str] = None,
        anchor_product_id: Optional[str] = None,
        user_liked_ids: Optional[List[str]] = None,
        top_k: int = DEFAULT_TOP_K,
        alpha: Optional[float] = None,
        category_filter: Optional[str] = None,
        max_price: Optional[float] = None,
    ) -> List[Dict[str, Any]]:
        """
        Generate hybrid recommendations combining content similarity and collaborative filtering.
        
        Args:
            user_id: Target user ID (for collaborative predictions)
            anchor_product_id: Product the user is currently viewing (for content similarity)
            user_liked_ids: List of products the user has liked or saved in wishlist
            top_k: Number of recommendations to return
            alpha: Custom weight for content score (0.0 = pure CF, 1.0 = pure Content)
            category_filter: Filter by category name
            max_price: Maximum price filter
        """
        effective_alpha = self.default_alpha if alpha is None else float(np.clip(alpha, 0.0, 1.0))

        # Check cold-start status for user
        is_user_cold = (user_id is None) or self.collab_engine.is_cold_start_user(user_id)

        # If user is cold-start and we have no anchor product or liked items, fallback to top-rated
        if is_user_cold and not anchor_product_id and not user_liked_ids:
            return self.content_engine.get_top_rated_fallback(top_k=top_k)

        # If user is cold-start, dynamically adapt alpha to 1.0 (pure content)
        if is_user_cold:
            effective_alpha = 1.0

        # 1. Compute Content Similarity Scores for all products
        content_scores: Dict[str, float] = {}
        target_product_meta = None

        if anchor_product_id and anchor_product_id in self.content_engine.id_to_idx:
            target_idx = self.content_engine.id_to_idx[anchor_product_id]
            target_product_meta = self.products_df.iloc[target_idx]
            sim_row = self.content_engine.similarity_matrix[target_idx]
            for idx, score in enumerate(sim_row):
                pid = self.content_engine.idx_to_id[idx]
                content_scores[pid] = float(score)

        elif user_liked_ids:
            valid_indices = [
                self.content_engine.id_to_idx[pid]
                for pid in user_liked_ids
                if pid in self.content_engine.id_to_idx
            ]
            if valid_indices:
                centroid = np.asarray(self.content_engine.tfidf_matrix[valid_indices].mean(axis=0))
                from sklearn.metrics.pairwise import cosine_similarity
                sims = cosine_similarity(centroid, self.content_engine.tfidf_matrix)[0]
                for idx, score in enumerate(sims):
                    pid = self.content_engine.idx_to_id[idx]
                    content_scores[pid] = float(score)

        # 2. Compute Collaborative Filtering Scores for all products
        collab_scores: Dict[str, float] = {}
        if not is_user_cold and user_id is not None:
            for pid in self.products_map.keys():
                pred_rating = self.collab_engine.predict_rating_item_based(user_id, pid)
                # Normalize predicted rating (1-5) to 0.0-1.0
                collab_scores[pid] = float(pred_rating / 5.0)

        # 3. Combine scores into Hybrid Score
        excluded_ids = set()
        if anchor_product_id:
            excluded_ids.add(anchor_product_id)
        if user_liked_ids:
            excluded_ids.update(user_liked_ids)

        scored_candidates = []
        for pid, prod in self.products_map.items():
            if pid in excluded_ids:
                continue

            # Category filter
            if category_filter and prod["category"].lower() != category_filter.lower():
                continue
            # Price filter
            if max_price is not None and prod["price"] > max_price:
                continue

            c_score = content_scores.get(pid, 0.0)
            cf_score = collab_scores.get(pid, (prod["rating"] / 5.0))

            hybrid_score = (effective_alpha * c_score) + ((1.0 - effective_alpha) * cf_score)

            scored_candidates.append(
                {
                    "product_id": pid,
                    "hybrid_score": hybrid_score,
                    "content_score": c_score,
                    "collab_score": cf_score,
                    "prod": prod,
                }
            )

        # Sort descending by hybrid score
        scored_candidates = sorted(
            scored_candidates, key=lambda x: x["hybrid_score"], reverse=True
        )

        # 4. Format recommendations with transparent explanation
        results = []
        for item in scored_candidates[:top_k]:
            prod = item["prod"]
            h_score = item["hybrid_score"]
            c_score = item["content_score"]
            cf_score = item["collab_score"]

            # Construct transparent academic explanation
            explanation_parts = []
            if effective_alpha > 0 and c_score > 0.1:
                explanation_parts.append(f"Content Match: {int(round(c_score * 100))}%")
            if effective_alpha < 1.0 and not is_user_cold:
                pred_stars = cf_score * 5.0
                explanation_parts.append(f"Collaborative Affinity: ★ {pred_stars:.1f}/5.0")
            elif is_user_cold:
                explanation_parts.append("Cold-Start Content Optimization")

            if target_product_meta is not None and prod["category"] == target_product_meta["category"]:
                explanation_parts.append(f"Category: {prod['category']}")

            explanation = " • ".join(explanation_parts) if explanation_parts else "Balanced hybrid recommendation"

            results.append(
                {
                    "product_id": prod["product_id"],
                    "name": prod["name"],
                    "category": prod["category"],
                    "subcategory": prod.get("subcategory", ""),
                    "brand": prod.get("brand", ""),
                    "price": prod["price"],
                    "rating": prod["rating"],
                    "rating_count": prod["rating_count"],
                    "image_url": prod["image_url"],
                    "description": prod["description"],
                    "hybrid_score": round(float(h_score), 4),
                    "content_score": round(float(c_score), 4),
                    "collab_score": round(float(cf_score), 4),
                    "match_percentage": f"{int(round(h_score * 100))}%",
                    "explanation": explanation,
                }
            )

        return results
