"""
Data loading and preprocessing module.
Handles CSV ingestion, data sanitization, missing value imputation,
duplicate handling, and feature text synthesis.
"""
from pathlib import Path
import re
from typing import Optional, Tuple
import pandas as pd
import numpy as np

from src.config import PRODUCTS_DATA_PATH, RATINGS_DATA_PATH, FALLBACK_IMAGE_URL


def clean_text(text: str) -> str:
    """Normalize and clean string text for NLP preprocessing."""
    if not isinstance(text, str):
        return ""
    text = text.lower()
    # Remove special punctuation while preserving alphanumerics and spaces
    text = re.sub(r"[^a-zA-Z0-9\s-]", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def load_products(file_path: Optional[Path] = None) -> pd.DataFrame:
    """
    Load and preprocess the products catalog dataset.
    
    Performs:
    - Safe loading
    - Column verification
    - Missing value imputation
    - Deduplication
    - Content 'soup' creation for TF-IDF feature extraction
    """
    path = file_path or PRODUCTS_DATA_PATH
    if not Path(path).exists():
        raise FileNotFoundError(f"Products dataset not found at {path}")

    df = pd.read_csv(path)

    # Required column checks
    required_cols = ["product_id", "name", "category", "price", "description"]
    missing_req = [col for col in required_cols if col not in df.columns]
    if missing_req:
        raise ValueError(f"Products file is missing required columns: {missing_req}")

    # Drop duplicates by product_id
    df = df.drop_duplicates(subset=["product_id"]).copy()

    # Handle missing / null fields gracefully
    df["name"] = df["name"].fillna("Unknown Product").astype(str)
    df["category"] = df["category"].fillna("General").astype(str)
    df["subcategory"] = df.get("subcategory", pd.Series(dtype=str)).fillna("General").astype(str)
    df["brand"] = df.get("brand", pd.Series(dtype=str)).fillna("Brand").astype(str)
    df["description"] = df["description"].fillna("").astype(str)
    df["tags"] = df.get("tags", pd.Series(dtype=str)).fillna("").astype(str)

    # Impute numeric fields
    df["price"] = pd.to_numeric(df["price"], errors="coerce")
    median_price = df["price"].median() if not df["price"].dropna().empty else 49.99
    df["price"] = df["price"].fillna(median_price).clip(lower=0.01)

    df["rating"] = pd.to_numeric(df.get("rating", pd.Series(dtype=float)), errors="coerce")
    df["rating"] = df["rating"].fillna(4.0).clip(lower=1.0, upper=5.0)

    df["rating_count"] = pd.to_numeric(df.get("rating_count", pd.Series(dtype=int)), errors="coerce")
    df["rating_count"] = df["rating_count"].fillna(10).astype(int)

    # Sanitize image URL
    df["image_url"] = df.get("image_url", pd.Series(dtype=str)).fillna(FALLBACK_IMAGE_URL)
    df["image_url"] = df["image_url"].apply(
        lambda x: x if isinstance(x, str) and (x.startswith("http://") or x.startswith("https://")) else FALLBACK_IMAGE_URL
    )

    # Synthesize content text 'soup' for Content-Based vectorization
    # Weights category and brand heavily by repeating them in the soup
    def build_soup(row: pd.Series) -> str:
        tokens = [
            clean_text(row["name"]),
            clean_text(row["category"]),
            clean_text(row["category"]),  # repeated for weight
            clean_text(row["subcategory"]),
            clean_text(row["brand"]),
            clean_text(row["tags"]),
            clean_text(row["description"]),
        ]
        return " ".join([t for t in tokens if t])

    df["content_soup"] = df.apply(build_soup, axis=1)

    return df


def load_ratings(file_path: Optional[Path] = None) -> pd.DataFrame:
    """
    Load and preprocess the user ratings dataset.
    
    Performs:
    - Safe loading
    - Column validation (user_id, product_id, rating)
    - Deduplication (keeps latest rating per user-product pair)
    - Rating bounds sanitization (1.0 to 5.0)
    """
    path = file_path or RATINGS_DATA_PATH
    if not Path(path).exists():
        # Return empty DataFrame with correct schema if no ratings file exists
        return pd.DataFrame(columns=["user_id", "product_id", "rating", "timestamp"])

    df = pd.read_csv(path)

    required_cols = ["user_id", "product_id", "rating"]
    missing = [c for c in required_cols if c not in df.columns]
    if missing:
        raise ValueError(f"Ratings file missing required columns: {missing}")

    # Clean types
    df["user_id"] = df["user_id"].astype(str).str.strip()
    df["product_id"] = df["product_id"].astype(str).str.strip()
    df["rating"] = pd.to_numeric(df["rating"], errors="coerce").fillna(3.0).clip(1.0, 5.0)

    if "timestamp" not in df.columns:
        df["timestamp"] = 0
    else:
        df["timestamp"] = pd.to_numeric(df["timestamp"], errors="coerce").fillna(0).astype(int)

    # Deduplicate user-product pair, keeping last interaction
    df = df.sort_values("timestamp").drop_duplicates(subset=["user_id", "product_id"], keep="last")

    return df


def get_dataset_summary(products_df: pd.DataFrame, ratings_df: pd.DataFrame) -> dict:
    """Compute dataset summary metrics for dashboards and reports."""
    num_products = len(products_df)
    categories = products_df["category"].unique().tolist()
    num_categories = len(categories)
    avg_price = float(products_df["price"].mean()) if num_products > 0 else 0.0
    avg_rating = float(products_df["rating"].mean()) if num_products > 0 else 0.0

    num_ratings = len(ratings_df)
    num_users = ratings_df["user_id"].nunique() if num_ratings > 0 else 0

    # User-Item matrix sparsity
    if num_users > 0 and num_products > 0:
        total_possible = num_users * num_products
        sparsity = (1.0 - (num_ratings / total_possible)) * 100.0
    else:
        sparsity = 100.0

    return {
        "num_products": num_products,
        "num_categories": num_categories,
        "categories": categories,
        "avg_price": round(avg_price, 2),
        "avg_rating": round(avg_rating, 2),
        "num_ratings": num_ratings,
        "num_users": num_users,
        "sparsity_percent": round(sparsity, 2),
    }
