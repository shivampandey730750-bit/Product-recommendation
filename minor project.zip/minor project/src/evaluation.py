"""
Model Evaluation and Metrics Module.
Calculates Precision@K, Recall@K, F1@K, Mean Reciprocal Rank (MRR),
and Catalog Coverage using train/test interaction splits.
"""
from typing import Dict, List, Set, Tuple, Any
import numpy as np
import pandas as pd

from src.content_based import ContentBasedRecommender
from src.collaborative import CollaborativeRecommender
from src.hybrid import HybridRecommender


def train_test_split_by_user(
    ratings_df: pd.DataFrame,
    test_ratio: float = 0.25,
    min_ratings: int = 3,
    random_state: int = 42,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Split interaction dataset into train and test sets per user.
    Ensures that evaluated users have interactions in both train and test partitions.
    """
    np.random.seed(random_state)
    train_records = []
    test_records = []

    user_counts = ratings_df["user_id"].value_counts()
    eligible_users = user_counts[user_counts >= min_ratings].index

    for uid, group in ratings_df.groupby("user_id"):
        if uid in eligible_users:
            shuffled = group.sample(frac=1.0, random_state=random_state)
            n_test = max(1, int(len(shuffled) * test_ratio))
            test_records.append(shuffled.iloc[:n_test])
            train_records.append(shuffled.iloc[n_test:])
        else:
            # Users with few ratings go to train to help collaborative signals
            train_records.append(group)

    train_df = pd.concat(train_records).reset_index(drop=True)
    test_df = pd.concat(test_records).reset_index(drop=True) if test_records else pd.DataFrame(columns=ratings_df.columns)

    return train_df, test_df


def compute_precision_recall_at_k(
    recommended_ids: List[str],
    relevant_ids: Set[str],
    k: int = 5,
) -> Tuple[float, float, float]:
    """
    Calculate Precision@K, Recall@K, and Reciprocal Rank for a single user recommendation list.
    """
    if not relevant_ids:
        return 0.0, 0.0, 0.0

    top_k_recs = recommended_ids[:k]
    hits = sum(1 for pid in top_k_recs if pid in relevant_ids)

    precision = hits / k if k > 0 else 0.0
    recall = hits / len(relevant_ids) if len(relevant_ids) > 0 else 0.0

    # Reciprocal rank
    rr = 0.0
    for rank_idx, pid in enumerate(top_k_recs, start=1):
        if pid in relevant_ids:
            rr = 1.0 / rank_idx
            break

    return precision, recall, rr


def evaluate_recommenders(
    products_df: pd.DataFrame,
    ratings_df: pd.DataFrame,
    k_values: List[int] = [3, 5, 10],
    relevance_threshold: float = 4.0,
    test_ratio: float = 0.25,
) -> Dict[str, Any]:
    """
    Run comprehensive evaluation benchmark comparing:
    - Content-Based Recommender (Taste Centroid)
    - Collaborative Filtering Recommender
    - Hybrid Recommender
    """
    if ratings_df.empty or len(ratings_df) < 5:
        return {"error": "Insufficient ratings for train/test evaluation"}

    train_df, test_df = train_test_split_by_user(ratings_df, test_ratio=test_ratio)
    if test_df.empty:
        return {"error": "Test set is empty; need more ratings per user"}

    # Initialize models on train partition
    content_engine = ContentBasedRecommender(products_df)
    collab_engine = CollaborativeRecommender(train_df, products_df)
    hybrid_engine = HybridRecommender(content_engine, collab_engine, default_alpha=0.5)

    # Build ground truth test dictionary: user_id -> set of positive product_ids (rating >= threshold)
    test_positives: Dict[str, Set[str]] = {}
    for uid, grp in test_df.groupby("user_id"):
        liked = set(grp[grp["rating"] >= relevance_threshold]["product_id"].unique())
        if liked:
            test_positives[uid] = liked

    eval_users = list(test_positives.keys())
    if not eval_users:
        # Fallback: take all test interactions as relevant if none >= threshold
        for uid, grp in test_df.groupby("user_id"):
            test_positives[uid] = set(grp["product_id"].unique())
        eval_users = list(test_positives.keys())

    # Results dictionary for metrics across models and k values
    results: Dict[str, Any] = {
        "num_eval_users": len(eval_users),
        "num_test_interactions": len(test_df),
        "models": {},
    }

    models_to_test = {
        "Content-Based": "content",
        "Collaborative Filtering": "collab",
        "Hybrid Model": "hybrid",
    }

    all_product_ids = set(products_df["product_id"].unique())

    for model_name, model_type in models_to_test.items():
        results["models"][model_name] = {}

        for k in k_values:
            precisions = []
            recalls = []
            reciprocal_ranks = []
            recommended_catalog_items: Set[str] = set()

            for uid in eval_users:
                relevant = test_positives[uid]
                # Train-seen items for this user to pass as context
                user_train_items = train_df[train_df["user_id"] == uid]["product_id"].tolist()

                if model_type == "content":
                    recs = content_engine.recommend_for_profile(
                        liked_product_ids=user_train_items, top_k=k, exclude_seen=True
                    )
                elif model_type == "collab":
                    recs = collab_engine.recommend_for_user(
                        user_id=uid, top_k=k, exclude_rated=True
                    )
                else:  # hybrid
                    recs = hybrid_engine.recommend(
                        user_id=uid,
                        user_liked_ids=user_train_items,
                        top_k=k,
                    )

                rec_ids = [r["product_id"] for r in recs]
                recommended_catalog_items.update(rec_ids)

                p, r, rr = compute_precision_recall_at_k(rec_ids, relevant, k=k)
                precisions.append(p)
                recalls.append(r)
                reciprocal_ranks.append(rr)

            mean_p = float(np.mean(precisions)) if precisions else 0.0
            mean_r = float(np.mean(recalls)) if recalls else 0.0
            mrr = float(np.mean(reciprocal_ranks)) if reciprocal_ranks else 0.0
            f1 = (
                float(2 * mean_p * mean_r / (mean_p + mean_r))
                if (mean_p + mean_r) > 0
                else 0.0
            )
            coverage = (
                float(len(recommended_catalog_items) / len(all_product_ids)) * 100.0
                if all_product_ids
                else 0.0
            )

            results["models"][model_name][f"K={k}"] = {
                "Precision": round(mean_p, 4),
                "Recall": round(mean_r, 4),
                "F1_Score": round(f1, 4),
                "MRR": round(mrr, 4),
                "Coverage_Pct": round(coverage, 2),
            }

    return results
